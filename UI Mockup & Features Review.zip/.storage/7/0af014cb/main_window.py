"""
Main window for the Outlook Automation Tool
"""

from PyQt6.QtWidgets import (QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, 
                           QSplitter, QStackedWidget, QLabel, QFrame, QPushButton,
                           QScrollArea, QSizePolicy)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QIcon, QFont, QPalette, QColor

from .sidebar import Sidebar
from .pages.dashboard import DashboardPage
from .pages.templates import TemplatesPage
from .pages.quick_actions import QuickActionsPage
from .pages.reminders import RemindersPage
from .pages.attachments import AttachmentsPage
from .pages.rsvp_tracker import RSVPTrackerPage
from .pages.settings import SettingsPage
from .components.status_bar import StatusBar
from .styles.theme_manager import ThemeManager

class MainWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        self.theme_manager = ThemeManager()
        self.current_page = "dashboard"
        
        self.setup_ui()
        self.setup_connections()
        self.setup_window()
        
        # Apply initial theme
        self.theme_manager.apply_theme(self, "light")
        
    def setup_ui(self):
        """Setup the user interface"""
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Create main layout
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Create splitter for sidebar and content
        splitter = QSplitter(Qt.Orientation.Horizontal)
        main_layout.addWidget(splitter)
        
        # Create sidebar
        self.sidebar = Sidebar()
        splitter.addWidget(self.sidebar)
        
        # Create content area
        content_frame = QFrame()
        content_frame.setFrameStyle(QFrame.Shape.StyledPanel)
        content_layout = QVBoxLayout(content_frame)
        content_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create header
        self.header = self.create_header()
        content_layout.addWidget(self.header)
        
        # Create stacked widget for pages
        self.stacked_widget = QStackedWidget()
        content_layout.addWidget(self.stacked_widget)
        
        # Create pages
        self.pages = {
            "dashboard": DashboardPage(),
            "templates": TemplatesPage(),
            "quick_actions": QuickActionsPage(),
            "reminders": RemindersPage(),
            "attachments": AttachmentsPage(),
            "rsvp_tracker": RSVPTrackerPage(),
            "settings": SettingsPage()
        }
        
        # Add pages to stacked widget
        for page in self.pages.values():
            self.stacked_widget.addWidget(page)
        
        splitter.addWidget(content_frame)
        
        # Set splitter proportions
        splitter.setSizes([250, 800])
        splitter.setCollapsible(0, False)
        
        # Create status bar
        self.status_bar = StatusBar()
        self.setStatusBar(self.status_bar)
        
    def create_header(self) -> QWidget:
        """Create the header widget"""
        header = QFrame()
        header.setObjectName("header")
        header.setFixedHeight(60)
        header.setFrameStyle(QFrame.Shape.StyledPanel)
        
        layout = QHBoxLayout(header)
        layout.setContentsMargins(20, 10, 20, 10)
        
        # Page title
        self.page_title = QLabel("Dashboard")
        self.page_title.setObjectName("pageTitle")
        font = QFont()
        font.setPointSize(18)
        font.setBold(True)
        self.page_title.setFont(font)
        layout.addWidget(self.page_title)
        
        layout.addStretch()
        
        # User info and auth status
        self.auth_status = QLabel("Not Connected")
        self.auth_status.setObjectName("authStatus")
        layout.addWidget(self.auth_status)
        
        self.connect_button = QPushButton("Connect to Outlook")
        self.connect_button.setObjectName("connectButton")
        layout.addWidget(self.connect_button)
        
        return header
    
    def setup_connections(self):
        """Setup signal-slot connections"""
        self.sidebar.page_changed.connect(self.change_page)
        self.connect_button.clicked.connect(self.handle_connect)
        
        # Connect page-specific signals if needed
        if hasattr(self.pages["settings"], "theme_changed"):
            self.pages["settings"].theme_changed.connect(self.change_theme)
    
    def setup_window(self):
        """Setup window properties"""
        self.setWindowTitle("Outlook Email Automation Tool")
        self.setMinimumSize(1000, 700)
        self.resize(1200, 800)
        
        # Center window on screen
        screen = self.screen()
        if screen:
            screen_geometry = screen.availableGeometry()
            x = (screen_geometry.width() - self.width()) // 2
            y = (screen_geometry.height() - self.height()) // 2
            self.move(x, y)
    
    def change_page(self, page_name: str):
        """Change the current page"""
        if page_name in self.pages:
            self.current_page = page_name
            page_widget = self.pages[page_name]
            self.stacked_widget.setCurrentWidget(page_widget)
            
            # Update page title
            page_titles = {
                "dashboard": "Dashboard",
                "templates": "Template Library",
                "quick_actions": "Quick Actions",
                "reminders": "Reminders",
                "attachments": "Attachments",
                "rsvp_tracker": "RSVP Tracker",
                "settings": "Settings"
            }
            
            self.page_title.setText(page_titles.get(page_name, page_name.title()))
            
            # Refresh page if it has a refresh method
            if hasattr(page_widget, "refresh"):
                page_widget.refresh()
    
    def handle_connect(self):
        """Handle Outlook connection"""
        # TODO: Implement Microsoft Graph authentication
        self.status_bar.show_message("Connecting to Outlook...", 3000)
        
        # Simulate connection process
        QTimer.singleShot(2000, self.on_connection_success)
    
    def on_connection_success(self):
        """Handle successful connection"""
        self.auth_status.setText("Connected")
        self.connect_button.setText("Disconnect")
        self.status_bar.show_message("Successfully connected to Outlook", 5000)
    
    def change_theme(self, theme_name: str):
        """Change application theme"""
        self.theme_manager.apply_theme(self, theme_name)
        
        # Update all pages
        for page in self.pages.values():
            if hasattr(page, "update_theme"):
                page.update_theme(theme_name)
    
    def closeEvent(self, event):
        """Handle window close event"""
        # Save window geometry
        # TODO: Save to config
        event.accept()