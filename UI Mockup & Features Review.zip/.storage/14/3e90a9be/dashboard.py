"""
Dashboard page for the Outlook Automation Tool
"""

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QFrame, QGridLayout, QScrollArea, QPushButton,
                           QListWidget, QListWidgetItem)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont, QPixmap

class MetricCard(QFrame):
    """Metric display card widget"""
    
    def __init__(self, title: str, value: str, subtitle: str = ""):
        super().__init__()
        self.setup_ui(title, value, subtitle)
    
    def setup_ui(self, title: str, value: str, subtitle: str):
        """Setup metric card UI"""
        self.setFrameStyle(QFrame.Shape.StyledPanel)
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border: 1px solid #e1e5e9;
                border-radius: 8px;
                padding: 16px;
            }
        """)
        self.setFixedHeight(120)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        
        # Title
        title_label = QLabel(title)
        title_label.setStyleSheet("color: #605e5c; font-size: 14px;")
        layout.addWidget(title_label)
        
        # Value
        value_label = QLabel(value)
        value_font = QFont()
        value_font.setPointSize(24)
        value_font.setBold(True)
        value_label.setFont(value_font)
        value_label.setStyleSheet("color: #323130;")
        layout.addWidget(value_label)
        
        # Subtitle
        if subtitle:
            subtitle_label = QLabel(subtitle)
            subtitle_label.setStyleSheet("color: #107c10; font-size: 12px;")
            layout.addWidget(subtitle_label)
        
        layout.addStretch()

class RecentActivityWidget(QFrame):
    """Recent activity display widget"""
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup recent activity UI"""
        self.setFrameStyle(QFrame.Shape.StyledPanel)
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border: 1px solid #e1e5e9;
                border-radius: 8px;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Header
        header_layout = QHBoxLayout()
        
        title = QLabel("Recent Activity")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title.setFont(title_font)
        header_layout.addWidget(title)
        
        header_layout.addStretch()
        
        view_all_btn = QPushButton("View All")
        view_all_btn.setStyleSheet("""
            QPushButton {
                color: #0078d4;
                border: none;
                font-size: 14px;
                text-decoration: underline;
            }
            QPushButton:hover {
                color: #106ebe;
            }
        """)
        header_layout.addWidget(view_all_btn)
        
        layout.addLayout(header_layout)
        
        # Activity list
        self.activity_list = QListWidget()
        self.activity_list.setFrameShape(QFrame.Shape.NoFrame)
        self.activity_list.setStyleSheet("""
            QListWidget {
                border: none;
                background: transparent;
            }
            QListWidget::item {
                padding: 8px 0px;
                border-bottom: 1px solid #f3f2f1;
            }
            QListWidget::item:last {
                border-bottom: none;
            }
        """)
        
        # Add sample activities
        activities = [
            "📧 Sent 'Weekly Update' template to 12 recipients",
            "⏰ Reminder sent for 'Project Meeting' to 8 people", 
            "📎 Downloaded 5 attachments from Sales folder",
            "✅ RSVP tracking updated for 'Team Standup'",
            "📝 Created new template 'Client Follow-up'"
        ]
        
        for activity in activities:
            item = QListWidgetItem(activity)
            self.activity_list.addItem(item)
        
        layout.addWidget(self.activity_list)

class QuickActionsWidget(QFrame):
    """Quick actions widget for dashboard"""
    
    action_clicked = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup quick actions UI"""
        self.setFrameStyle(QFrame.Shape.StyledPanel)
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border: 1px solid #e1e5e9;
                border-radius: 8px;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Header
        title = QLabel("Quick Actions")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title)
        
        # Action buttons grid
        actions_layout = QGridLayout()
        actions_layout.setSpacing(12)
        
        actions = [
            ("📅 Zoom Invite", "zoom_invite", "#0078d4"),
            ("📝 Follow-up", "follow_up", "#107c10"),
            ("🙏 Thank You", "thank_you", "#ff8c00"),
            ("📎 Attachments", "attachments", "#5c2d91")
        ]
        
        for i, (text, action, color) in enumerate(actions):
            btn = QPushButton(text)
            btn.setFixedHeight(60)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {color};
                    color: white;
                    border: none;
                    border-radius: 6px;
                    font-size: 14px;
                    font-weight: bold;
                    padding: 12px;
                }}
                QPushButton:hover {{
                    background-color: rgba({int(color[1:3], 16)}, {int(color[3:5], 16)}, {int(color[5:7], 16)}, 0.9);
                }}
            """)
            btn.clicked.connect(lambda checked, a=action: self.action_clicked.emit(a))
            actions_layout.addWidget(btn, i // 2, i % 2)
        
        layout.addLayout(actions_layout)

class DashboardPage(QWidget):
    """Main dashboard page"""
    
    def __init__(self):
        super().__init__()
        self.setObjectName("contentPage")
        self.setup_ui()
    
    def setup_ui(self):
        """Setup dashboard UI"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)
        
        # Metrics row
        metrics_layout = QHBoxLayout()
        metrics_layout.setSpacing(20)
        
        # Create metric cards
        metrics = [
            ("Templates Created", "15", "+3 this week"),
            ("Emails Sent", "142", "+28 this week"),
            ("Responses Tracked", "89", "62.7% response rate"),
            ("Reminders Sent", "23", "+5 pending")
        ]
        
        for title, value, subtitle in metrics:
            card = MetricCard(title, value, subtitle)
            metrics_layout.addWidget(card)
        
        layout.addLayout(metrics_layout)
        
        # Content row
        content_layout = QHBoxLayout()
        content_layout.setSpacing(20)
        
        # Recent activity (left side)
        recent_activity = RecentActivityWidget()
        content_layout.addWidget(recent_activity, 2)
        
        # Quick actions (right side)
        quick_actions = QuickActionsWidget()
        quick_actions.action_clicked.connect(self.handle_quick_action)
        content_layout.addWidget(quick_actions, 1)
        
        layout.addLayout(content_layout)
        
        layout.addStretch()
    
    def handle_quick_action(self, action: str):
        """Handle quick action button click"""
        # TODO: Emit signal to main window to change page or open dialog
        print(f"Quick action clicked: {action}")
    
    def refresh(self):
        """Refresh dashboard data"""
        # TODO: Update metrics and recent activity
        pass